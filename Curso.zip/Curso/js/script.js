/**
 * Exemplos da aula 
 * Criação de variável  e calculo de valores
 */